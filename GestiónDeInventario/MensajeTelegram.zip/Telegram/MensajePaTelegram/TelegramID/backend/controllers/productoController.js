const productoModel = require('../models/productoModel');

const obtenerProductos = async (req, res) => {
    const { nombre } = req.query;
    try {
        const productos = nombre
            ? await productoModel.buscarPorNombre(nombre)
            : await productoModel.obtenerTodos();
        res.json(productos);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const agregarProducto = async (req, res) => {
    try {
        const producto = req.body;

        // Validación de datos
        if (!producto.nombre || !producto.precio_compra || !producto.margen_utilidad) {
            return res.status(400).json({ error: 'Faltan datos obligatorios' });
        }

        // Cálculo corregido del precio de venta
        producto.precio_venta = producto.precio_compra * (1 + 0.19 + producto.margen_utilidad / 100);

        const nuevoProducto = await productoModel.agregar(producto);
        res.json(nuevoProducto);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const actualizarProducto = async (req, res) => {
    try {
        const id = req.params.id;
        const producto = req.body;

        // Validación de datos
        if (!producto.nombre || !producto.precio_compra || !producto.margen_utilidad) {
            return res.status(400).json({ error: 'Faltan datos obligatorios' });
        }

        // Cálculo corregido del precio de venta
        producto.precio_venta = producto.precio_compra * (1 + 0.19 + producto.margen_utilidad / 100);

        const productoActualizado = await productoModel.actualizar(id, producto);
        res.json(productoActualizado);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const eliminarProducto = async (req, res) => {
    try {
        const id = req.params.id;
        await productoModel.eliminar(id);
        res.sendStatus(204);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

module.exports = {
    obtenerProductos,
    agregarProducto,
    actualizarProducto,
    eliminarProducto
};
