const fetch = require('node-fetch');
const TELEGRAM_TOKEN = '7930342752:AAGBzTv_mHHVYdoEayDaQYym9AfsgJIksCo';
const CHAT_ID = '7665242620';

const enviarNotificacionStock = async (producto) => {
    const mensaje = ` Stock bajo\nProducto: ${producto.nombre}\nStock actual:
    ${producto.stock}`;
     try {
        const res = await
    fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        BODY: JSON.stringify({ chat_id: CHAT_ID, text: mensaje })
     });
      const data = await res.json();
      if (!data.ok) console.error("Telegram error:", data.description);
     } catch (error) {
        console.error("Error al enviar mensaje a Telegram:", error);
     }
};

module.exports = { enviarNotificacionStock };