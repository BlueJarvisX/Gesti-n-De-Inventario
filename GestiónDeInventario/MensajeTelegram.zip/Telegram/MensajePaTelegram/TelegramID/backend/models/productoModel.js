const db = require('../db/database');
const { enviarNotificacionStock } = require('../utils/telegram'); // Importamos la función para enviar notificación

const obtenerTodos = () => {
    return new Promise((resolve, reject) => {
        db.all('SELECT * FROM productos', [], (err, rows) => {
            if (err) reject(err);
            resolve(rows);
        });
    });
};

const agregar = (producto) => {
    return new Promise((resolve, reject) => {
        const { nombre, stock, categoria, precio_compra, margen_utilidad, precio_venta } = producto;
        db.run(
            `INSERT INTO productos (nombre, stock, categoria, precio_compra, margen_utilidad, precio_venta) VALUES (?, ?, ?, ?, ?, ?)`,
            [nombre, stock, categoria, precio_compra, margen_utilidad, precio_venta],
            function (err) {
                if (err) reject(err);

                // Si el stock es menor o igual a 5, enviamos la notificación
                if (stock <= 5) {
                    enviarNotificacionStock({ nombre, stock });
                }

                resolve({ id: this.lastID, ...producto });
            }
        );
    });
};

const actualizar = (id, producto) => {
    return new Promise((resolve, reject) => {
        const { nombre, stock, categoria, precio_compra, margen_utilidad, precio_venta } = producto;
        db.run(
            `UPDATE productos SET nombre = ?, stock = ?, categoria = ?, precio_compra = ?, margen_utilidad = ?, precio_venta = ? WHERE id = ?`,
            [nombre, stock, categoria, precio_compra, margen_utilidad, precio_venta, id],
            function (err) {
                if (err) reject(err);

                // Si el stock es menor o igual a 5, enviamos la notificación
                if (stock <= 5) {
                    enviarNotificacionStock({ nombre, stock });
                }

                resolve({ id, ...producto });
            }
        );
    });
};

const eliminar = (id) => {
    return new Promise((resolve, reject) => {
        db.run(`DELETE FROM productos WHERE id = ?`, [id], function (err) {
            if (err) reject(err);
            resolve();
        });
    });
};

const buscarPorNombre = (nombre) => {
    return new Promise((resolve, reject) => {
        db.all(
            `SELECT * FROM productos WHERE nombre LIKE ?`,
            [`%${nombre}%`],
            (err, rows) => {
                if (err) reject(err);
                resolve(rows);
            }
        );
    });
};

module.exports = {
    obtenerTodos,
    agregar,
    actualizar,
    eliminar,
    buscarPorNombre
};

