const API_URL = 'http://localhost:3000/api/productos';

const mostrarProductosEnTabla = (productos) => {
    const tabla = document.getElementById('tablaProductos');
    tabla.innerHTML = ''; // Limpiar tabla
    productos.forEach((producto) => {
        const fila = document.createElement('tr');
        fila.innerHTML = `
            <td>${producto.nombre}</td>
            <td>${producto.stock}</td>
            <td>${producto.categoria}</td>
            <td>${producto.precio_compra}</td>
            <td>${producto.margen_utilidad}</td>
            <td>${producto.precio_venta}</td>
        `;
        tabla.appendChild(fila);
    });
};

const cargarProductos = async () => {
    const response = await fetch(API_URL);
    const productos = await response.json();
    const productosTabla = document.getElementById('productosTabla');
    productosTabla.innerHTML = ''; // Limpiar tabla
    productos.forEach((producto) => agregarProductoATabla(producto, producto.id));
};

const agregarOActualizarProducto = async (event) => {
    event.preventDefault();
    const id = document.getElementById('productoId').value;
    const producto = {
        nombre: document.getElementById('nombre').value,
        stock: parseInt(document.getElementById('stock').value),
        categoria: document.getElementById('categoria').value,
        precio_compra: parseFloat(document.getElementById('precio_compra').value),
        margen_utilidad: parseFloat(document.getElementById('margen_utilidad').value)
    };

    const method = id ? 'PUT' : 'POST';
    const url = id ? `${API_URL}/${id}` : API_URL;

    await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(producto)
    });

    document.getElementById('productoForm').reset();
    cargarProductos();
};

const editarProducto = async (id) => {
    const response = await fetch(`${API_URL}/${id}`);
    const producto = await response.json();
    document.getElementById('productoId').value = producto.id;
    document.getElementById('nombre').value = producto.nombre;
    document.getElementById('stock').value = producto.stock;
    document.getElementById('categoria').value = producto.categoria;
    document.getElementById('precio_compra').value = producto.precio_compra;
    document.getElementById('margen_utilidad').value = producto.margen_utilidad;
};

const eliminarProducto = async (id) => {
    await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
    cargarProductos();
};

const buscarProductosPorNombre = async (nombre) => {
    const response = await fetch(`${API_URL}?nombre=${nombre}`);
    const productos = await response.json();
    mostrarProductosEnTabla(productos);
};

const agregarProductoATabla = (producto, id) => {
    const productosTabla = document.getElementById('productosTabla');
    const nuevaFila = document.createElement('tr');
    nuevaFila.dataset.id = id; // Asignar el ID al atributo de la fila
    nuevaFila.innerHTML = `
        <td>${producto.nombre}</td>
        <td>${producto.stock}</td>
        <td>${producto.categoria}</td>
        <td>${producto.precio_compra.toFixed(2)}</td>
        <td>${producto.margen_utilidad.toFixed(2)}%</td>
        <td>${producto.precio_venta.toFixed(2)}</td>
        <td>
            <button class="editar" onclick="editarProducto(${id})">Editar</button>
            <button class="eliminar" onclick="eliminarProducto(${id})">Eliminar</button>
        </td>
    `;
    productosTabla.appendChild(nuevaFila);
};

document.getElementById('productoForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const id = document.getElementById('productoId').value;
    const producto = {
        nombre: document.getElementById('nombre').value,
        stock: parseInt(document.getElementById('stock').value),
        categoria: document.getElementById('categoria').value,
        precio_compra: parseFloat(document.getElementById('precio_compra').value),
        margen_utilidad: parseFloat(document.getElementById('margen_utilidad').value),
        precio_venta: parseFloat(document.getElementById('precio_compra').value) * (1 + parseFloat(document.getElementById('margen_utilidad').value) / 100)
    };

    const method = id ? 'PUT' : 'POST';
    const url = id ? `${API_URL}/${id}` : API_URL;

    await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(producto)
    });

    document.getElementById('productoForm').reset();
    cargarProductos();
});

document.getElementById('buscar').addEventListener('input', (event) => {
    const filtro = event.target.value.toLowerCase();
    const filas = document.querySelectorAll('#productosTabla tr');
    filas.forEach(fila => {
        const nombre = fila.children[0].textContent.toLowerCase();
        fila.style.display = nombre.includes(filtro) ? '' : 'none';
    });
});

document.getElementById('buscarNombre').addEventListener('input', (event) => {
  const filtro = event.target.value.toLowerCase();
  const filas = document.querySelectorAll('#tablaProductos tr');
  filas.forEach(fila => {
    const nombre = fila.children[0].textContent.toLowerCase();
    fila.style.display = nombre.includes(filtro) ? '' : 'none';
  });
});

document.getElementById('buscarNombre').addEventListener('input', (event) => {
    const nombre = event.target.value;
    if (nombre) {
        buscarProductosPorNombre(nombre);
    } else {
        cargarProductos();
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const productoForm = document.getElementById("productoForm");
    const productosTabla = document.getElementById("productosTabla");

    // Cargar productos desde localStorage
    const cargarProductos = () => {
        const productos = JSON.parse(localStorage.getItem("productos")) || [];
        productosTabla.innerHTML = "";
        productos.forEach((producto, index) => agregarProductoTabla(producto, index));
    };

    // Guardar productos en localStorage
    const guardarProductos = (productos) => {
        localStorage.setItem("productos", JSON.stringify(productos));
    };

    // Agregar producto a la tabla
    const agregarProductoTabla = (producto, index) => {
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${producto.nombre}</td>
            <td>${producto.stock}</td>
            <td>${producto.categoria}</td>
            <td>${producto.precio_compra}</td>
            <td>${producto.margen_utilidad}</td>
            <td>${producto.precio_venta}</td>
            <td>
                <button class="editar" data-index="${index}">Editar</button>
                <button class="eliminar" data-index="${index}">Eliminar</button>
            </td>
        `;
        productosTabla.appendChild(fila);
    };

    // Manejar el envío del formulario
    productoForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const nombre = document.getElementById("nombre").value;
        const stock = document.getElementById("stock").value;
        const categoria = document.getElementById("categoria").value;
        const precio_compra = parseFloat(document.getElementById("precio_compra").value);
        const margen_utilidad = parseFloat(document.getElementById("margen_utilidad").value);
        const precio_venta = (precio_compra * (1 + 0.19 + margen_utilidad)).toFixed(2);

        const nuevoProducto = { nombre, stock, categoria, precio_compra, margen_utilidad, precio_venta };
        const productos = JSON.parse(localStorage.getItem("productos")) || [];
        productos.push(nuevoProducto);
        guardarProductos(productos);
        agregarProductoTabla(nuevoProducto, productos.length - 1);
        productoForm.reset();
    });

    // Manejar clics en los botones de la tabla
    productosTabla.addEventListener("click", (e) => {
        const productos = JSON.parse(localStorage.getItem("productos")) || [];
        const index = e.target.dataset.index;

        if (e.target.classList.contains("eliminar")) {
            productos.splice(index, 1);
            guardarProductos(productos);
            cargarProductos();
        }

        if (e.target.classList.contains("editar")) {
            const producto = productos[index];
            document.getElementById("nombre").value = producto.nombre;
            document.getElementById("stock").value = producto.stock;
            document.getElementById("categoria").value = producto.categoria;
            document.getElementById("precio_compra").value = producto.precio_compra;
            document.getElementById("margen_utilidad").value = producto.margen_utilidad;

            productos.splice(index, 1);
            guardarProductos(productos);
            cargarProductos();
        }
    });

    // Inicializar tabla
    cargarProductos();
});

document.addEventListener('DOMContentLoaded', cargarProductos);
